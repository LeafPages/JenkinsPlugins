/* exported echartsJenkinsApi */
function EChartsJenkinsApi () { /* Empty placeholder */ }
const echartsJenkinsApi = new EChartsJenkinsApi();
